import pandas as pd
train=pd.read_csv('heart.csv')

train.head()

train.isnull().sum()

X = train.drop(columns='target', axis=1)
Y = train['target']

print(X)

train['target'].value_counts()

X = train.drop(columns='target', axis=1)
Y = train['target']

print(Y)

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=2)

print(X.shape, X_train.shape, X_test.shape)

model=LogisticRegression()

model.fit(X_train, Y_train)

X_train_prediction = model.predict(X_train)
training_data_accuracy = accuracy_score(X_train_prediction, Y_train)

print('Accuracy on Training data : ', training_data_accuracy)

X_test_prediction = model.predict(X_test)
test_data_accuracy = accuracy_score(X_test_prediction, Y_test)
print('Accuracy on Test data : ', test_data_accuracy)

a=[]
for i in range(0,13):
    e=float(input())
    a.append(e)
a1=np.asarray(a)
a1_reshape=a1.reshape(1,-1)
prediction=model.predict(a1_reshape)
if prediction==0:
    print("Does not have heart disease.")
else:
    print("Have Heart Disease.")
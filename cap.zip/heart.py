import pandas as pd
train=pd.read_csv('framingham.csv')

train.head()

train.isnull().sum()

train.dropna(axis=0,inplace=True)

X = train.drop(columns='TenYearCHD', axis=1)
Y = train['TenYearCHD']



import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, stratify=Y, random_state=2)

model=LogisticRegression()

model.fit(X_train, Y_train)

X_train_prediction = model.predict(X_train)
training_data_accuracy = accuracy_score(X_train_prediction, Y_train)
X_test_prediction = model.predict(X_test)
test_data_accuracy = accuracy_score(X_test_prediction, Y_test)
print('Accuracy:', test_data_accuracy)

from flask import Flask, render_template,request
import smtplib
server=smtplib.SMTP_SSL("smtp.gmail.com",465)
server.login("shreeshyleshronaldo@gmail.com","dmeoxpyfgnlwhtlh")
app = Flask(__name__,static_folder='static')
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/result',methods=['POST'])
def result():
    sex=int(request.form['sex'])
    age=int(request.form['age'])
    currentSmoker = int(request.form['currentSmoker'])
    cigsPerDay = int(request.form['cigsPerDay'])
    BPMeds = int(request.form['BPMeds'])
    prevalentStroke = int(request.form['prevalentStroke'])
    prevalentHyp = int(request.form['prevalentHyp'])
    diabetes = int(request.form['diabetes'])
    totChol = int(request.form['totChol'])
    sysBP = float(request.form['sysBP'])
    diaBP = int(request.form['diaBP'])
    BMI = float(request.form['BMI'])
    heartRate = int(request.form['heartRate'])
    glucose = int(request.form['glucose'])
    m=request.form['mail']
    
    x=np.array([sex,age,currentSmoker,cigsPerDay,BPMeds,prevalentStroke,prevalentHyp,diabetes,totChol,sysBP,diaBP,BMI,heartRate,glucose]).reshape(1,-1)
    prediction=model.predict(x)
    if prediction==0:
        server.sendmail("shreeshyleshronaldo@gmail.com",m,"No Risk")
        return render_template("negative.html")
        
    else:
        server.sendmail("shreeshyleshronaldo@gmail.com",m,"Risk")
        return render_template('positive.html')
  
if __name__=="__main__":
    app.run(debug=False,port=7384)
    
  


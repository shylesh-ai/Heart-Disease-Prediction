import pandas as pd
import scipy.stats as st
import numpy as np
import statsmodels.api as sm
train=pd.read_csv('framingham.csv')

train.head()

train.isnull().sum()

train.dropna(axis=0,inplace=True)

from statsmodels.tools import add_constant as add_constant
train_constant = add_constant(train)
train_constant.head()

st.chisqprob = lambda chisq, df: st.chi2.sf(chisq, df)
cols=train_constant.columns[:-1]
model=sm.Logit(train.TenYearCHD,train_constant[cols])
result=model.fit()
result.summary()

import sklearn
new_features=train[['sex','age','cigsPerDay','totChol','sysBP','heartRate','glucose','TenYearCHD']]
x=new_features.iloc[:,:-1]
y=new_features.iloc[:,-1]
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.20,random_state=5)

from sklearn.linear_model import LogisticRegression
logreg=LogisticRegression()
logreg.fit(x_train,y_train)
y_pred=logreg.predict(x_test)

print(sklearn.metrics.accuracy_score(y_test,y_pred))

from flask import Flask, render_template,request
import smtplib
server=smtplib.SMTP_SSL("smtp.gmail.com",465)
server.login("shreeshyleshronaldo@gmail.com","dmeoxpyfgnlwhtlh")
app = Flask(__name__,static_folder='static')
@app.route('/')
def index():
    return render_template('index.html')
@app.route('/result',methods=['POST'])
def result():
    sex=int(request.form['sex'])
    age=int(request.form['age'])
    currentSmoker = int(request.form['currentSmoker'])
    cigsPerDay = int(request.form['cigsPerDay'])
    BPMeds = int(request.form['BPMeds'])
    prevalentStroke = int(request.form['prevalentStroke'])
    prevalentHyp = int(request.form['prevalentHyp'])
    diabetes = int(request.form['diabetes'])
    totChol = int(request.form['totChol'])
    sysBP = float(request.form['sysBP'])
    diaBP = int(request.form['diaBP'])
    BMI = float(request.form['BMI'])
    heartRate = int(request.form['heartRate'])
    glucose = int(request.form['glucose'])
    m=request.form['mail']
    
    x=np.array([sex,age,cigsPerDay,totChol,sysBP,heartRate,glucose]).reshape(1,-1)
    prediction=logreg.predict(x) 
    if prediction==0:
        server.sendmail("shreeshyleshronaldo@gmail.com",m,"No Risk")
        return render_template("negative.html")
        
    else:
        server.sendmail("shreeshyleshronaldo@gmail.com",m,"Risk")
        return render_template('positive.html')
  
if __name__=="__main__":
    app.run(debug=False,port=7384)